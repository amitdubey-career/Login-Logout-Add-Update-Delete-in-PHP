<?php
include('config.php');
if(isset($_GET['id'])) {
	$id=$_GET['id'];

	$query="delete from data where id='$id'";
	if ($conn->query($query) === TRUE) {
		header('location:list.php');
	} else {
		echo "Error deleting record: " . $conn->error;
	}
}

?>