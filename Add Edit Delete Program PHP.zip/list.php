<?php include('header.php'); ?>
<div class="container">
<h1>User List</h1>
<?php
$query="select * from data";
$result=$conn->query($query);
	echo "<div class='main-agileits'>";
	echo "<div class='form-w3-agile'>";
	echo "<div class='table-responsive'>";
	echo "<table class='table table-bordered'>";
	echo "<tr class='danger'><th>NAME</th><th>E-MAIL</th><th>MOBILE</th><th>COLOR</th><th style='text-align:center;' colspan=2>ACTION</th>";
	while($row=$result->fetch_array()) {
		echo "<tr><td>".$row['name']."</td>";
		echo "<td>".$row['email']."</td>";
		echo "<td>".$row['mobile']."</td>";
		echo "<td>".$row['color']."</td>";
		echo "<td style='text-align:center;'><a class='edit' href='edit.php?id=".$row['id']."'><i class='fa fa-pencil-square-o'></i></a></td>";
		echo "<td style='text-align:center;'><a class='delete' href='delete.php?id=".$row['id']."'><i class='fa fa-trash-o'></i></a></td></tr>";
	}
	echo "</tr>";
	echo "</table>";
	echo "</div>";
	echo "</div>";
	echo "</div>";
	mysqli_close($conn);
?>
	<div class="col-md-12"><a style="float:right;" href="home.php">Click here to go to home page...</a></div>
	<div class="copyright w3-agile">
		<p> © 2017 All rights reserved | Design by <a href="#" target="_blank">Amit Dubey</a></p>
	</div> 
</div>


<?php
include('footer.php');
?>