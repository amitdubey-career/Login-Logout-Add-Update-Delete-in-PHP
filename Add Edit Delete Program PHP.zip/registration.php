<?php include('config.php'); ?>
<?php include('header.php'); ?>
<?php
if($_SERVER["REQUEST_METHOD"]=="POST") {
	$fname=$_POST['fname'];
	$lname=$_POST['lname'];
	$email=$_POST['email'];
	$password=md5($_POST['password']);
	$mobile=$_POST['mobile'];
	$gender=$_POST['gender'];
	
	$query = "INSERT INTO admin (fname, lname, email, password, mobile, gender) VALUES ('$fname', '$lname', '$email', '$password', '$mobile', '$gender')";
	
	if ($conn->query($query) === TRUE) {
			header('location:index.php');
		} else {
			echo "<div class='container'>";
			echo "<div class='col-md-12'>";
			echo "<p class='alert alert-danger'>Error: </p>" . $sql . "<br>" . $conn->error;
			echo "</div>";
			echo "</div>";
		}
}
?>
			<div class="container">
				<h1>Registration Form</h1>
				<div class="main-agileits">
					<div class="form-w3-agile">
						<h2>Register Now</h2>
						<form action="#" method="post">
							<div class="form-sub-w3 form-group col-md-6">
								<input type="text" name="fname" placeholder="First Name" required="" />
								<div class="icon-w3">
									<i class="fa fa-user" aria-hidden="true"></i>
								</div>
							</div>
							<div class="form-sub-w3 form-group col-md-6">
								<input type="text" name="lname" placeholder="Last Name" required="" />
								<div class="icon-w3">
									<i class="fa fa-user" aria-hidden="true"></i>
								</div>
							</div>
							<div class="form-sub-w3 form-group col-md-6">
								<input type="text" name="email" placeholder="Email" required="" />
								<div class="icon-w3">
									<i class="fa fa-envelope-o" aria-hidden="true"></i>
								</div>
							</div>
							<div class="form-sub-w3 form-group col-md-6">
								<input type="password" name="password" placeholder="Password" required="" />
								<div class="icon-w3">
									<i class="fa fa-unlock-alt" aria-hidden="true"></i>
								</div>
							</div>
							<div class="form-sub-w3 form-group col-md-6">
								<input type="password" name="cpassword" placeholder="Confirm Password"/>
								<div class="icon-w3">
									<i class="fa fa-unlock-alt" aria-hidden="true"></i>
								</div>
							</div>
							<div class="form-sub-w3 form-group col-md-6">
								<input type="text" name="mobile" placeholder="Mobile" required="" />
								<div class="icon-w3">
									<i class="fa fa-mobile" aria-hidden="true"></i>
								</div>
							</div>
							<div class="form-group col-md-12 gender-select">
								<select type="select" name="gender" class="form-control select-dropdown" id="sel1">
									<option value="Select Your Gender" data-placeholder="All Types" disabled selected>Select Your Gender</option>
									<option value="male">Male</option>
									<option value="female">Female</option>
								</select>
							</div>
							<div class="clear"></div>
							<div class="submit-w3l">
								<input type="submit" name="submit" value="Register">
							</div>
						</form>
					</div>
				</div>
				<div class="copyright w3-agile">
					<p> © 2017 All rights reserved | Design by <a href="#" target="_blank">Amit Dubey</a></p>
				</div> 
			</div>
        
<?php include('footer.php'); ?>