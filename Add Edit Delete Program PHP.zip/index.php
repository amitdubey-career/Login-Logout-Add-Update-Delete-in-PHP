<?php include('header.php'); ?>
<?php 
session_start();
if(isset($_SESSION['login_user'])) {
	header('location:home.php');
}
?>
<?php 
	
		
	if(isset($_POST['login'])){
		
		if(empty($_POST['email']) || empty($_POST['password'])) 
		{
			echo $error="Invalid E-Mail and Password";
		} 
		
		else{
			$email=$_POST['email'];
		 	$password=$_POST['password'];
			
			$sql = "SELECT * FROM admin WHERE email = '".$email."' AND password='".md5($password)."'";
			$result = $conn->query($sql);
			//var_dump($result);
			if ($result->num_rows > 0) {
				//echo "success";
				 $_SESSION['login_user'] = $email;
				 header('location:home.php');
			} else {
				echo "<div class='alert alert-danger'>error</div>";
			}
			$conn->close();
		}
	}
	
?>
			<div class="container">
				<h1>Login Form</h1>
				<div class="main-agileits">
					<div class="form-w3-agile">
						<h2>login Now</h2>
						<form action="" method="post" enctype="multipart/form-data">
							<div class="form-sub-w3 form-group">
								<input type="text" name="email" placeholder="E-Mail " required="" />
								<div class="icon-w3">
									<i class="fa fa-user" aria-hidden="true"></i>
								</div>
							</div>
							<div class="form-sub-w3 form-group">
								<input type="password" name="password" placeholder="Password" required="" />
								<div class="icon-w3">
									<i class="fa fa-unlock-alt" aria-hidden="true"></i>
								</div>
							</div>
							<div class="checkbox form-group remember-me">
								<label><input type="checkbox"> Remember me</label>
							</div>
							<p class="p-bottom-w3ls">Forgot Password?<a href="#">  Click here</a></p>
							<p class="p-bottom-w3ls1">New User?<a href="registration.php">  Register here</a></p>
							<div class="clear"></div>
							<div class="submit-w3l">
								<input type="submit" name="login" value="Login">
							</div>
						</form>
					</div>
				</div>
				<div class="copyright w3-agile">
					<p> © 2017 All rights reserved | Design by <a href="#" target="_blank">Amit Dubey</a></p>
				</div> 
			</div>
        
<?php include('footer.php'); ?>