<?php
include('header.php');
if(isset($_GET['id'])) {

	$id=$_GET['id'];

	if(isset($_POST['update'])) {

		$name=$_POST['name'];
		$email=$_POST['email'];
		$mobile=$_POST['mobile'];
		$color=$_POST['color'];

		$query="update data set name='$name',email='$email',mobile='$mobile', color='$color' where id='$id'";
		if ($conn->query($query) === TRUE) {
			header('location:list.php');
		} else {
			echo "Error updating record: " . $conn->error;
		}
	}

	$var="select * from data where id='$id'";
	$result=$conn->query($var);
	while($output=$result->fetch_array()) {
		$name=$output['name'];
		$email=$output['email'];
		$mobile=$output['mobile'];
		$color=$output['color'];
	}


?>
		<h1>Update Your Data</h1>
		<form class="main-form edit-form" method="post" action="" enctype="multipart/form-data">
			<div class="form-sub-w3 form-group">
				<label>Name:</label>
				<input type="text" name="name" value="<?php echo $name; ?>" class="form-control" placeholder="Name" required>
			</div>
			<div class="form-sub-w3 form-group">
				<label>Email:</label>
				<input type="text" name="email" value="<?php echo $email; ?>" class="form-control" placeholder="Email" required>
			</div>
			<div class="form-sub-w3 form-group">
				<label>Mobile:</label>
				<input type="text" name="mobile" value="<?php echo $mobile; ?>" class="form-control" placeholder="Mobile" required>
			</div>
			<div class="form-sub-w3 form-group">
				<label>Color:</label>
				<div class="radio">
					<label><input type="radio" name="color" value="Red" <?php if($color=='R') echo 'checked="checked"'; ?> required /> Red</label>
				</div>
				<div class="radio">
					<label><input type="radio" name="color" value="Green" <?php if($color=='G') echo 'checked="checked"'; ?> required /> Green</label>
				</div>
				<div class="radio">
					<label><input type="radio" name="color" value="Blue" <?php if($color=='B') echo 'checked="checked"'; ?> required /> Blue</label>
				</div>
			</div>
			<button type="submit" name="update" class="btn btn-primary">Update Query</button>
		</form>
		<div class="copyright w3-agile">
			<p> © 2017 All rights reserved | Design by <a href="#" target="_blank">Amit Dubey</a></p>
		</div>
		<?php
		}
		?>
	<?php
	include('footer.php');
	?>