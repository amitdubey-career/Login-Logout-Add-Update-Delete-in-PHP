		</div>
	</div>
</div>	
<script src="js/jquery.min.js" type="text/javascript"></script>
<script src="js/bootstrap.min.js" type="text/javascript"></script>
<script type="text/javascript">
	$(document).ready(function() {
		$("a.delete").click(function(e){
			if(!confirm('Are You Sure?')) {
				e.preventDefault();
				return false;
			}
			return true;
		})
	})
</script>
<script>
    function isNumberKey(evt){
        var charCode = (evt.which) ? evt.which : event.keyCode
    if (charCode > 31 && (charCode < 48 || charCode > 57))
        return false;
    return true;
    }
</script>
</body>
</html>