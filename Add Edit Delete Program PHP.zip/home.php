
<?php include('header.php'); ?>



<?php
session_start();
if(isset($_SESSION['login_user'])) {
	


if(isset($_POST['submit'])) {

	$name=$_POST['name'];
	$email=$_POST['email'];
	$mobile=$_POST['mobile'];
	$color=$_POST['color'];
	
	if($color!="") {
		$sql="INSERT INTO data(name, email, mobile, color) values ('$name','$email','$mobile','$color')";
		if ($conn->query($sql) === TRUE) {
			header('location:list.php');
		} else {
			echo "<div class='container'>";
			echo "<div class='col-md-12'>";
			echo "<p class='alert alert-danger'>Error: </p>" . $sql . "<br>" . $conn->error;
			echo "</div>";
			echo "</div>";
		}
	}
	//mysqli_close($conn);
	$conn->close();
}

?>
			<div class="container">
				<div class="col-md-12">
					<div class="login-panel">
						<h3 class="hello">Hello, <?php echo $_SESSION['login_user']; ?></h3>
						<a class="btn btn-danger pull-right" href="logout.php" style="font-size:18px">Logout?</a>
					</div>
				</div>
			</div>
			<div class="container">
				<h1>Fill The Form</h1>
				<div class="row">
					<div class="col-md-12">
						<form id="list-form" class="main-form" method="post" action="" enctype="multipart/form-data">
							<div class="form-sub-w3 form-group">
								<input type="text" name="name" class="form-control" placeholder="Name" required>
							</div>
							<div class="form-sub-w3 form-group">
								<input type="text" name="email" class="form-control" placeholder="Email" required>
							</div>
							<div class="form-sub-w3 form-group">
								<input type="text" name="mobile" class="form-control" placeholder="Mobile" onkeypress="return isNumberKey(event)" minlength="10" maxlength="10" required>
							</div>
							<div class="form-sub-w3 form-group choose-one">
								<label>Color:</label>
								<div class="radio">
									<label><input type="radio" name="color" value="Red" required> Red</label>
								</div>
								<div class="radio">
									<label><input type="radio" name="color" value="Green" required> Green</label>
								</div>
								<div class="radio">
									<label><input type="radio" name="color" value="Blue" required> Blue</label>
								</div>
							</div>
							<div class="submit-w3l">
								<input type="submit" name="submit">
							</div>
						</form>
					</div>
				</div>
				<div class="copyright w3-agile">
				<p> © 2017 All rights reserved | Design by <a href="#" target="_blank">Amit Dubey</a></p>
			</div>
			</div>
		
<?php
include('footer.php');

} else {

		header('location:index.php');
	}
?>