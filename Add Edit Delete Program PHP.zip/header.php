<?php include('config.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
<title>PHP Practices - With Login, Registration, and Add, Update Delete</title>
<meta name="viewport" content="width=device-width, initial-scale=1" />
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/style.css">
<link href="fonts.googleapis.com/css?family=Sirin+Stencil" rel="stylesheet">
<body>
<div class="demo-1">
	<div class="content">
        <div id="large-header" class="large-header">
	
	