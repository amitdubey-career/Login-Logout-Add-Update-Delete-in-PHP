<?php
include('config.php');
session_start();
$user_check=$_SESSION['login_user'];
 
$sql = mysqli_query($conn,"SELECT fname FROM admin WHERE email='$user_check' ");
 
$row=mysqli_fetch_array($sql,MYSQLI_ASSOC);
 
$login_user=$row['fname'];
 
if(!isset($user_check))
{
header("Location: index.php");
}
?>